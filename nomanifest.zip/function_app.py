import azure.functions as func
import logging
import os
import requests
import json
import uuid

app = func.FunctionApp()

@app.event_hub_message_trigger(arg_name="azeventhub", event_hub_name="dt-appsec-event-hub",
                               connection="EventHubConnectionString") 
def eventhub_trigger(azeventhub: func.EventHubEvent):
    logging.info('Custom - Python EventHub trigger processed an event: %s',
                azeventhub.get_body().decode('utf-8'))

    event_body = azeventhub.get_body().decode('utf-8')
    event_json = json.loads(event_body)
    event_uuid = str(uuid.uuid4())
    event_json['uuid'] = event_uuid
    payload = json.dumps([event_json])
    logging.info(f'Payload: {payload}')

    PostDynatraceEvent(payload)


def PostDynatraceEvent(payload):
    DT_API_URL = os.environ["DT_API_URL"]
    DT_TOKEN = os.environ["DT_TOKEN"] 
    HEADERS = {'Authorization': 'Api-Token ' + DT_TOKEN, 'Content-Type': 'application/json; charset=utf-8'}
    logging.info(f"Using url = {DT_API_URL}")

    r = requests.post(DT_API_URL, data=payload, headers=HEADERS)
    logging.info(f"Request status: {r.status_code}")

    if not r.ok:
        logging.error(f"Request text: {r.text}")
